import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";
export const maxDuration = 90;

type ResearchMode = "Rápida" | "Aprofundada" | "Acadêmica";

const modeGuide: Record<ResearchMode, string> = {
  "Rápida": "Produza uma resposta objetiva, com contexto essencial e fontes prioritárias. Investigue o suficiente para confirmar os pontos centrais.",
  "Aprofundada": "Faça uma investigação em múltiplas etapas. Decomponha a pergunta em subtópicos, procure fontes diversas, compare evidências, procure divergências e indique lacunas.",
  "Acadêmica": "Priorize artigos revisados por pares, revisões sistemáticas, universidades, periódicos, repositórios científicos e documentos oficiais. Distinga estudos primários, revisões e documentos institucionais. Não invente DOI, autores, periódicos ou dados bibliográficos.",
};

const SYSTEM_PROMPT = `Você é o pesquisador acadêmico e educacional da Academia IA. Responda em português brasileiro.
Use a ferramenta de busca na web de verdade. Nunca afirme que consultou toda a internet. Não invente fontes, autores, datas, links, DOI, citações ou resultados.
Priorize fontes primárias e institucionais quando pertinentes. Compare fontes independentes e verifique se cada fonte realmente sustenta a afirmação associada.
Organize a resposta com estes títulos:
## Resumo da investigação
## Pergunta central e subtópicos
## Análise das evidências
## O que está confirmado
## Controvérsias e limitações
## Lacunas e próximos passos
## Conclusão
Use marcadores [FATO], [INTERPRETAÇÃO] ou [INCERTO] quando isso ajudar a distinguir o grau de sustentação.
Inclua referências no próprio texto usando as citações fornecidas pela ferramenta de busca. Não crie uma bibliografia fictícia.
Se encontrar poucas fontes confiáveis, diga isso. Se a pergunta for ambígua, declare a interpretação adotada.`;

function isMode(value: unknown): value is ResearchMode {
  return value === "Rápida" || value === "Aprofundada" || value === "Acadêmica";
}

export async function POST(request: NextRequest) {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return NextResponse.json(
      { error: "Pesquisa ainda não configurada. Adicione OPENAI_API_KEY ao ambiente do servidor." },
      { status: 503 },
    );
  }

  try {
    const body = await request.json();
    const query = typeof body.query === "string" ? body.query.trim() : "";
    const mode: ResearchMode = isMode(body.mode) ? body.mode : "Aprofundada";
    if (query.length < 4 || query.length > 1500) {
      return NextResponse.json({ error: "A pergunta deve ter entre 4 e 1.500 caracteres." }, { status: 400 });
    }

    const input = `${modeGuide[mode]}\n\nPergunta do estudante: ${query}\n\nFaça a busca na web, cite fontes verificáveis e deixe explícito o que não conseguiu confirmar.`;
    const upstream = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: process.env.OPENAI_RESEARCH_MODEL || "gpt-5.4",
        instructions: SYSTEM_PROMPT,
        tools: [{ type: "web_search", search_context_size: mode === "Rápida" ? "medium" : "high" }],
        tool_choice: "required",
        input,
        max_output_tokens: mode === "Rápida" ? 1800 : 3500,
      }),
      signal: AbortSignal.timeout(85000),
    });

    if (!upstream.ok) {
      const detail = await upstream.text();
      console.error("Research provider error:", upstream.status, detail.slice(0, 500));
      return NextResponse.json(
        { error: upstream.status === 401 ? "A chave de IA foi recusada. Confira a configuração no servidor." : "O serviço de pesquisa está temporariamente indisponível." },
        { status: 502 },
      );
    }

    const result = await upstream.json();
    const textParts: string[] = [];
    const sourceMap = new Map<string, { title: string; url: string }>();
    for (const item of result.output ?? []) {
      if (item.type !== "message") continue;
      for (const part of item.content ?? []) {
        if (part.type === "output_text" && typeof part.text === "string") textParts.push(part.text);
        for (const annotation of part.annotations ?? []) {
          if (annotation.type === "url_citation" && typeof annotation.url === "string") {
            try {
              const url = new URL(annotation.url);
              if (url.protocol === "https:" || url.protocol === "http:") {
                sourceMap.set(url.href, { title: String(annotation.title || url.hostname).slice(0, 240), url: url.href });
              }
            } catch {}
          }
        }
      }
    }
    const report = textParts.join("\n\n").trim();
    if (!report) {
      return NextResponse.json({ error: "A pesquisa não retornou um relatório legível. Tente reformular a pergunta." }, { status: 502 });
    }

    return NextResponse.json({
      report,
      sources: Array.from(sourceMap.values()).slice(0, 20),
      mode,
      searchedAt: new Date().toISOString(),
      model: process.env.OPENAI_RESEARCH_MODEL || "gpt-5.4",
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "";
    return NextResponse.json(
      { error: message.includes("JSON") ? "Formato de solicitação inválido." : "A pesquisa excedeu o tempo ou não pôde ser concluída. Tente novamente." },
      { status: 400 },
    );
  }
}
