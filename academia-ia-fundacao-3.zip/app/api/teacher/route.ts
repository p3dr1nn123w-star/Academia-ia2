import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";

type Message = { role: "student" | "assistant"; text: string };

const TEACHER_PROMPT = `Você é o professor virtual da Academia IA. Fale sempre em português brasileiro, com energia positiva, clareza e personalidade original.
Seu objetivo é ensinar, não apenas entregar respostas. Primeiro identifique o nível provável do estudante; explique em etapas curtas, use exemplos cotidianos e verifique a compreensão com uma pergunta quando fizer sentido.
Se houver dificuldade, mude a abordagem e ofereça pistas progressivas. Não afirme que o estudante domina um assunto com base em uma única resposta.
Em tarefas escolares, ajude o estudante a raciocinar. Em redações, não escreva o texto completo quando o objetivo for praticar autonomia; ofereça orientação e feedback.
Se não souber algo ou não tiver contexto suficiente, diga isso claramente. Não invente fontes, dados ou citações. Seja acolhedor, respeitoso e conciso, sem imitar a voz de personagens ou atores.`;

export async function POST(request: NextRequest) {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return NextResponse.json(
      { error: "A integração ainda não foi configurada. Adicione OPENAI_API_KEY ao ambiente do servidor e reinicie a aplicação." },
      { status: 503 },
    );
  }

  try {
    const body = await request.json();
    if (!Array.isArray(body.messages) || body.messages.length === 0 || body.messages.length > 16) {
      return NextResponse.json({ error: "Envie de 1 a 16 mensagens válidas." }, { status: 400 });
    }
    const messages = (body.messages as Message[]).map((item) => {
      if (!item || !["student", "assistant"].includes(item.role) || typeof item.text !== "string") {
        throw new Error("Formato de mensagem inválido.");
      }
      return { role: item.role === "student" ? "user" : "assistant", content: item.text.slice(0, 5000) };
    });

    const upstream = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
        temperature: 0.65,
        max_tokens: 900,
        messages: [{ role: "system", content: TEACHER_PROMPT }, ...messages],
      }),
      signal: AbortSignal.timeout(30000),
    });

    if (!upstream.ok) {
      const detail = await upstream.text();
      console.error("Teacher provider error:", upstream.status, detail.slice(0, 500));
      return NextResponse.json({ error: upstream.status === 401 ? "A chave de IA foi recusada. Confira a configuração do servidor." : "O serviço de IA está temporariamente indisponível." }, { status: 502 });
    }

    const result = await upstream.json();
    const reply = result.choices?.[0]?.message?.content;
    if (typeof reply !== "string" || !reply.trim()) {
      return NextResponse.json({ error: "O serviço não retornou uma resposta válida." }, { status: 502 });
    }
    return NextResponse.json({ reply: reply.trim() });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Erro inesperado.";
    return NextResponse.json({ error: message.includes("inválido") ? message : "Não foi possível concluir a conversa. Tente novamente." }, { status: 400 });
  }
}
