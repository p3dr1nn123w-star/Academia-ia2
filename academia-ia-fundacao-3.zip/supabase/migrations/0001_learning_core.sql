-- Academia IA: núcleo de persistência para Supabase/PostgreSQL.
-- Aplicar apenas depois de configurar um projeto Supabase e revisar políticas no ambiente.

create extension if not exists pgcrypto;

create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text check (char_length(display_name) <= 100),
  learning_preferences jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.conversations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null default 'Nova conversa' check (char_length(title) <= 180),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint conversations_id_user_unique unique (id, user_id)
);

create table public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('student', 'assistant')),
  content text not null check (char_length(content) <= 12000),
  created_at timestamptz not null default now(),
  constraint messages_conversation_owner_match foreign key (conversation_id, user_id)
    references public.conversations(id, user_id) deferrable initially immediate
);

-- A chave composta garante que a mensagem pertença ao mesmo usuário da conversa.
create table public.research_runs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  query text not null check (char_length(query) between 4 and 1500),
  mode text not null check (mode in ('Rápida', 'Aprofundada', 'Acadêmica')),
  report text not null,
  sources jsonb not null default '[]'::jsonb,
  model text,
  searched_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

create table public.essays (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  theme text not null check (char_length(theme) <= 500),
  content text not null check (char_length(content) <= 12000),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint essays_id_user_unique unique (id, user_id)
);

create table public.essay_evaluations (
  id uuid primary key default gen_random_uuid(),
  essay_id uuid not null references public.essays(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  estimated_total integer not null check (estimated_total between 0 and 1000),
  competencies jsonb not null check (jsonb_typeof(competencies) = 'array' and jsonb_array_length(competencies) = 5),
  overall_comment text not null,
  evaluated_at timestamptz not null default now(),
  constraint essay_evaluation_owner_match foreign key (essay_id, user_id)
    references public.essays(id, user_id) deferrable initially immediate
);


create table public.learning_progress (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  subject text not null check (char_length(subject) <= 100),
  topic text not null check (char_length(topic) <= 180),
  status text not null default 'needs_learning' check (status in ('mastered', 'developing', 'needs_learning')),
  mastery_score numeric(4,3) check (mastery_score between 0 and 1),
  attempts integer not null default 0 check (attempts >= 0),
  last_reviewed_at timestamptz,
  updated_at timestamptz not null default now(),
  unique (user_id, subject, topic)
);

create index conversations_user_updated_idx on public.conversations(user_id, updated_at desc);
create index messages_conversation_created_idx on public.messages(conversation_id, created_at);
create index research_runs_user_created_idx on public.research_runs(user_id, created_at desc);
create index essays_user_updated_idx on public.essays(user_id, updated_at desc);
create index essay_evaluations_user_date_idx on public.essay_evaluations(user_id, evaluated_at desc);
create index learning_progress_user_subject_idx on public.learning_progress(user_id, subject, status);

create trigger profiles_set_updated_at before update on public.profiles
for each row execute function public.set_updated_at();
create trigger conversations_set_updated_at before update on public.conversations
for each row execute function public.set_updated_at();
create trigger essays_set_updated_at before update on public.essays
for each row execute function public.set_updated_at();
create trigger learning_progress_set_updated_at before update on public.learning_progress
for each row execute function public.set_updated_at();

alter table public.profiles enable row level security;
alter table public.conversations enable row level security;
alter table public.messages enable row level security;
alter table public.research_runs enable row level security;
alter table public.essays enable row level security;
alter table public.essay_evaluations enable row level security;
alter table public.learning_progress enable row level security;

create policy "profiles_select_own" on public.profiles for select to authenticated using (id = auth.uid());
create policy "profiles_insert_own" on public.profiles for insert to authenticated with check (id = auth.uid());
create policy "profiles_update_own" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
create policy "profiles_delete_own" on public.profiles for delete to authenticated using (id = auth.uid());
create policy "conversations_owner_all" on public.conversations for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "messages_select_own" on public.messages for select to authenticated using (user_id = auth.uid() and exists (select 1 from public.conversations c where c.id = conversation_id and c.user_id = auth.uid()));
create policy "messages_insert_student" on public.messages for insert to authenticated with check (user_id = auth.uid() and role = 'student' and exists (select 1 from public.conversations c where c.id = conversation_id and c.user_id = auth.uid()));
create policy "messages_update_student" on public.messages for update to authenticated using (user_id = auth.uid() and role = 'student') with check (user_id = auth.uid() and role = 'student');
create policy "messages_delete_own" on public.messages for delete to authenticated using (user_id = auth.uid());
create policy "research_runs_owner_all" on public.research_runs for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "essays_owner_all" on public.essays for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "essay_evaluations_select_own" on public.essay_evaluations for select to authenticated using (user_id = auth.uid() and exists (select 1 from public.essays e where e.id = essay_id and e.user_id = auth.uid()));
create policy "essay_evaluations_delete_own" on public.essay_evaluations for delete to authenticated using (user_id = auth.uid());
create policy "learning_progress_owner_all" on public.learning_progress for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

grant select, insert, update, delete on public.profiles, public.conversations, public.messages,
  public.research_runs, public.essays, public.essay_evaluations, public.learning_progress to authenticated;
